import requests

# Microsoft Fabric Credentials
TENANT_ID = "0eadb77e-42dc-47f8-bbe3-ec2395e0712c"
CLIENT_ID = "b307dfaa-6307-4b99-8a8b-eb1fdcb206a6"
CLIENT_SECRET = "MLF8Q~vF6R3487goRJy1G-n7MTXnqFJzMUt5Mc7U"

def get_powerbi_access_token():
    url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
    payload = {
        "grant_type": "client_credentials",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "scope": "https://graph.microsoft.com/.default"
    }
    headers = {"Content-Type": "application/x-www-form-urlencoded"}

    response = requests.post(url, data=payload, headers=headers)
    if response.status_code == 200:
        return response.json()["access_token"]
    else:
        raise Exception(f"Error getting token: {response.text}")

access_token = get_powerbi_access_token()
print("✅ Power BI Access Token Obtained")

WORKSPACE_ID = "89723aa4-edf2-4d37-95ce-a65c4c74d490"
DATASET_NAME = "Tableau_Metadata_Dataset"
LAKEHOUSE_ID = "fdbff903-75a2-4448-b585-a62cdf941d61"
TABLE_NAME = "tableau_metadata"

url = f"https://api.powerbi.com/v1.0/myorg/groups/{WORKSPACE_ID}/datasets"

headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

payload = {
    "name": DATASET_NAME,
    "defaultMode": "Push",
    "tables": [
        {
            "name": TABLE_NAME,
            "columns": [
                {"name": "Workbook_Name", "dataType": "String"},
                {"name": "Dashboard_Name", "dataType": "String"},
                {"name": "Dashboard_ID", "dataType": "String"},
                {"name": "Dashboard_URL", "dataType": "String"},
                {"name": "Visual_Type", "dataType": "String"},
                {"name": "Columns_Used", "dataType": "String"}
            ]
        }
    ],
    "datasources": [
        {
            "datasourceType": "FabricLakehouse",
            "connectionDetails": {
                "workspaceId": WORKSPACE_ID,
                "lakehouseId": LAKEHOUSE_ID
            }
        }
    ]
}

response = requests.post(url, json=payload, headers=headers)

if response.status_code in [200, 201]:
    print("✅ Dataset created successfully!")
else:
    print(f"🚨 Error creating Dataset: {response.text}")
REPORT_NAME = "Tableau_Analysis_Report"

url = f"https://api.powerbi.com/v1.0/myorg/groups/{WORKSPACE_ID}/reports"

payload = {
    "name": REPORT_NAME,
    "datasetId": "your-dataset-id",  # Replace with actual dataset ID
    "visualizations": [
        {
            "type": "Table",
            "title": "Dashboard List",
            "fields": ["Workbook_Name", "Dashboard_Name", "Visual_Type", "Columns_Used"]
        },
        {
            "type": "BarChart",
            "title": "Visualization Distribution",
            "xField": "Visual_Type",
            "yField": "COUNT(Dashboard_Name)"
        }
    ]
}

response = requests.post(url, json=payload, headers=headers)

if response.status_code in [200, 201]:
    print("✅ Report created successfully!")
else:
    print(f"🚨 Error creating report: {response.text}")

DATASET_ID = "your-dataset-id"  # Replace with actual dataset ID

url = f"https://api.powerbi.com/v1.0/myorg/groups/{WORKSPACE_ID}/datasets/{DATASET_ID}/refreshes"

payload = {"notifyOption": "NoNotification"}

response = requests.post(url, json=payload, headers=headers)

if response.status_code == 202:
    print("✅ Dataset refresh triggered!")
else:
    print(f"🚨 Error triggering refresh: {response.text}")

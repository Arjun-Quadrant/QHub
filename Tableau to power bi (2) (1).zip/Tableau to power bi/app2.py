import requests
import pandas as pd
import xml.etree.ElementTree as ET
from flask import Flask, request, render_template, jsonify
import csv 
import io

app = Flask(__name__)

# ==========================
# 🔹 Tableau Server Details
# ==========================
TABLEAU_SERVER = "https://prod-apnortheast-a.online.tableau.com"
API_VERSION = "3.24"
SITE_NAME = ""  # Leave empty for the default site

# ==========================
# 🔹 Microsoft Fabric Details
# ==========================
CLIENT_ID = "b307dfaa-6307-4b99-8a8b-eb1fdcb206a6"
CLIENT_SECRET = "MLF8Q~vF6R3487goRJy1G-n7MTXnqFJzMUt5Mc7U"
TENANT_ID = "0eadb77e-42dc-47f8-bbe3-ec2395e0712c"
FABRIC_WORKSPACE_ID = "89723aa4-edf2-4d37-95ce-a65c4c74d490"
FABRIC_LAKEHOUSE_ID = "fdbff903-75a2-4448-b585-a62cdf941d61"
TABLE_NAME = "tableau_metadata"

# ==========================
# 🔹 File Path
# ==========================
CSV_FILE_PATH = "tableau_metadata.csv"

# ==========================
# 🔹 Get OAuth Token for Microsoft Fabric
# ==========================
def get_fabric_access_token():
    url = f"https://login.microsoftonline.com/{TENANT_ID}/oauth2/v2.0/token"
    payload = {
        "grant_type": "client_credentials",
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "scope": "https://api.fabric.microsoft.com/.default"
    }
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response = requests.post(url, data=payload, headers=headers)

    if response.status_code != 200:
        raise Exception(f"🚨 Failed to get Fabric access token: {response.status_code}\n{response.text}")

    return response.json()["access_token"]

# ==========================
# 🔹 Authenticate with Tableau
# ==========================
def get_auth_token(username, password):
    url = f"{TABLEAU_SERVER}/api/{API_VERSION}/auth/signin"
    payload = f"""
        <tsRequest>
            <credentials name="{username}" password="{password}">
                <site contentUrl="{SITE_NAME}"/>
            </credentials>
        </tsRequest>
    """
    headers = {"Content-Type": "application/xml"}
    response = requests.post(url, data=payload, headers=headers)

    if response.status_code != 200:
        raise Exception(f"🚨 Tableau Authentication Failed! {response.status_code}\n{response.text}")

    root = ET.fromstring(response.text)
    namespaces = {"t": "http://tableau.com/api"}
    token_elem = root.find(".//t:credentials", namespaces)
    token = token_elem.get("token")
    site_id = root.find(".//t:site", namespaces).get("id")

    return token, site_id

# ==========================
# 🔹 Fetch Dashboards from Tableau
# ==========================
def get_dashboards(auth_token, site_id):
    url = f"{TABLEAU_SERVER}/api/{API_VERSION}/sites/{site_id}/workbooks"
    headers = {"X-Tableau-Auth": auth_token}
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        root = ET.fromstring(response.text)
        dashboards = []
        for workbook in root.findall(".//t:workbook", namespaces={"t": "http://tableau.com/api"}):
            workbook_id = workbook.get("id")
            workbook_name = workbook.get("name")
            dashboards.extend(get_sheets(auth_token, site_id, workbook_id, workbook_name))
        return dashboards
    else:
        raise Exception(f"🚨 Failed to fetch Tableau workbooks! Error: {response.text}")

# ==========================
# 🔹 Fetch Sheets (Dashboards) from Tableau
# ==========================
# Fetch View (Dashboard) Data from Tableau
def get_visual_metadata(auth_token, site_id, view_id):
    # 1️⃣ Fetch metadata from Tableau API
    url = f"{TABLEAU_SERVER}/api/{API_VERSION}/sites/{site_id}/views/{view_id}"
    headers = {"X-Tableau-Auth": auth_token}

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        try:
            root = ET.fromstring(response.text)
            view_element = root.find(".//t:view", namespaces={"t": "http://tableau.com/api"})
            
            if view_element is not None:
                visual_type = view_element.get("contentType", "Unknown")  # Get visualization type
            else:
                visual_type = "Unknown"
            
        except Exception as e:
            print(f"🚨 XML Parsing Error: {e}")
            visual_type = "Unknown"
    else:
        print(f"🚨 API Error: {response.status_code} - {response.text}")
        visual_type = "Unknown"

    # 2️⃣ Fetch column names (if needed)
    data_url = f"{TABLEAU_SERVER}/api/{API_VERSION}/sites/{site_id}/views/{view_id}/data"
    data_response = requests.get(data_url, headers=headers)

    columns_used = []
    if data_response.status_code == 200:
        response_text = data_response.text.strip()
        if response_text and "," in response_text[:100]:  
            try:
                csv_data = io.StringIO(response_text)
                reader = csv.reader(csv_data)
                columns_used = next(reader)  # Extract column headers (first row)
            except Exception as e:
                print(f"🚨 CSV Parsing Error: {e}")

    return visual_type, columns_used



# Fetch Sheets (Dashboards) from Tableau with Actual Data
def get_sheets(auth_token, site_id, workbook_id, workbook_name):
    url = f"{TABLEAU_SERVER}/api/{API_VERSION}/sites/{site_id}/workbooks/{workbook_id}/views"
    headers = {"X-Tableau-Auth": auth_token}
    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        root = ET.fromstring(response.text)
        sheets = []
        for sheet in root.findall(".//t:view", namespaces={"t": "http://tableau.com/api"}):
            sheet_name = sheet.get("name")
            sheet_id = sheet.get("id")
            content_url = sheet.get("contentUrl")

            # 🔹 Get actual visual type and columns used
            visual_type, columns_used = get_visual_metadata(auth_token, site_id, sheet_id)

            sheets.append({
                "Workbook_Name": workbook_name,
                "Dashboard_Name": sheet_name,
                "Dashboard_ID": sheet_id,
                "Dashboard_URL": f"{TABLEAU_SERVER}/#/site/{site_id}/views/{content_url}",
                "Visual_Type": visual_type,  # Now it shows actual chart type
                "Columns_Used": ", ".join(columns_used) if columns_used else "N/A"
            })
        return sheets
    else:
        return []

# ==========================
# 🔹 Save Metadata to CSV
# ==========================
def save_metadata_to_csv(dashboards):
    df = pd.DataFrame(dashboards)
    df.to_csv(CSV_FILE_PATH, index=False)
    print(f"✅ Metadata saved to {CSV_FILE_PATH}")

# ==========================
# 🔹 Upload File to OneLake
# ==========================
def upload_file_to_onelake():
    try:
        access_token = get_fabric_access_token()

        url = f"https://onelake.dfs.fabric.microsoft.com/{FABRIC_WORKSPACE_ID}/{FABRIC_LAKEHOUSE_ID}.lakehouse/Files/"
        print(f"URL for file upload: {url}")

        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }

        with open(CSV_FILE_PATH, 'rb') as file:
            files = {'file': (CSV_FILE_PATH, file, 'application/json')}
            payload = {"relativePath": f"Files/{CSV_FILE_PATH}", "fileExtension": "csv"}

            response = requests.post(url, headers=headers, files=files, data=payload)

            if response.status_code == 200:
                print("✅ File uploaded successfully to OneLake!")
            else:
                print(f"🚨 Error uploading file to OneLake: {response.status_code}\n{response.text}")
    
    except Exception as e:
        print(f"🚨 Error during file upload: {str(e)}")

# ==========================
# 🔹 Upload CSV to Microsoft Fabric
# ==========================
def upload_csv_to_fabric():
    access_token = get_fabric_access_token()

    url = f"https://api.fabric.microsoft.com/v1/workspaces/{FABRIC_WORKSPACE_ID}/lakehouses/{FABRIC_LAKEHOUSE_ID}/tables/{TABLE_NAME}/load"

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    payload = {
        "relativePath": f"Files/{CSV_FILE_PATH}",
        "pathType": "File",
        "mode": "append",
        "recursive": False,
        "formatOptions": {
            "format": "Csv",
            "header": True,
            "delimiter": ","
        }
    }

    response = requests.post(url, json=payload, headers=headers)

    if response.status_code in [200, 202]:
        print("✅ CSV successfully uploaded and appended to Microsoft Fabric table!")
    else:
        print(f"🚨 Error uploading CSV: {response.status_code}\n{response.text}")

# ==========================
# 🔹 Migration Function
# ==========================
def migrate_to_fabric(username, password):
    auth_token, site_id = get_auth_token(username, password)
    dashboards = get_dashboards(auth_token, site_id)

    save_metadata_to_csv(dashboards)
    upload_file_to_onelake()
    upload_csv_to_fabric()

# ==========================
# 🔹 Flask API to Trigger Migration
# ==========================
@app.route('/')
def home():
    return render_template('index.html')  # This will show the form

# Handle the Form Submission
@app.route('/migrate', methods=['POST'])
def migrate():
    try:
        username = request.form.get("username")  # Get username from form
        password = request.form.get("password")  # Get password from form

        if not username or not password:
            return jsonify({"error": "Username and password are required"}), 400

        # Call the migration function
        migrate_to_fabric(username, password)

        return jsonify({"message": "Data migration to Microsoft Fabric successful!"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
